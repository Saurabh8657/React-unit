const Navbar = () => {
  return <>
    <div className="navbar">
      <h1>React Redux Restaurant Display App</h1>
    </div>
  </>;
};

export default Navbar;
