export type Todo = {
    id: string ,
    task: string ,
    status: boolean
}