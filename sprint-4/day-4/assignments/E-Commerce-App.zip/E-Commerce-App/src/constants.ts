// {"id":1,"brand":"Zebronics","img":"https://adn-static1.nykaa.com/nykdesignstudio-images/tr:w-550,/pub/media/catalog/product/n/y/nyfboat000113_1_cc965b26.jpg?rnd=20200526195200","price":100,"details":"Lorem ipsum dolor sit amet consectetur adipisicing elit. Iusto, sequi.","category":"Laptop"}

export type ProductObj = {
    id: number;
    brand: string;
    img: string;
    price: number;
    details: string;
    category: string;
}

export type actionType = {
    type: string;
    payload: ProductObj
}